// src/app/gifts/page.tsx
'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/supabase';

type Gift = {
  id: string;
  name: string;
  price: number | null;
  store: string | null;
  brand: string | null;
  status: string;
  image_url: string | null;
  created_at: string;
};

type Recipient = {
  id: string;
  name: string;
};

type GiftWithRecipients = Gift & {
  recipients: Recipient[];
};

export default function GiftsPage() {
  const supabase = createClient();
  const [gifts, setGifts] = useState<GiftWithRecipients[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchGifts();
  }, []);

  async function fetchGifts() {
    try {
      // First, fetch all gifts
      const { data: giftsData, error: giftsError } = await supabase
        .from('gifts')
        .select('*')
        .order('created_at', { ascending: false });

      if (giftsError) throw giftsError;

      // Then, fetch all gift-recipient relationships
      const { data: linksData, error: linksError } = await supabase
        .from('gift_recipients')
        .select(`
          gift_id,
          recipient_id,
          recipients (
            id,
            name
          )
        `);

      if (linksError) throw linksError;

      // Combine the data
      const giftsWithRecipients = giftsData.map((gift) => {
        const giftLinks = linksData.filter((link: any) => link.gift_id === gift.id);
        const recipients = giftLinks.map((link: any) => link.recipients);
        return {
          ...gift,
          recipients,
        };
      });

      setGifts(giftsWithRecipients);
      setLoading(false);
    } catch (err) {
      console.error('Error fetching gifts:', err);
      setError('Failed to load gifts');
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 py-12 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="text-gray-600">Loading gifts...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 py-12 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="text-red-600">{error}</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 mb-2">Gift Ideas</h1>
            <p className="text-gray-600">Track and manage all your gift ideas</p>
          </div>
          <Link
            href="/gifts/new"
            className="px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-medium"
          >
            + Add Gift
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="text-2xl font-bold text-gray-900">{gifts.length}</div>
            <div className="text-sm text-gray-500">Total Gifts</div>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="text-2xl font-bold text-blue-600">
              {gifts.filter((g) => g.status === 'idea').length}
            </div>
            <div className="text-sm text-gray-500">Ideas</div>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="text-2xl font-bold text-green-600">
              {gifts.filter((g) => g.status === 'purchased').length}
            </div>
            <div className="text-sm text-gray-500">Purchased</div>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="text-2xl font-bold text-purple-600">
              ${gifts.reduce((sum, g) => sum + (g.price || 0), 0).toFixed(2)}
            </div>
            <div className="text-sm text-gray-500">Total Value</div>
          </div>
        </div>

        {/* Gifts Grid */}
        {gifts.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-500 mb-4">No gifts yet. Add your first gift idea!</div>
            <Link
              href="/gifts/new"
              className="inline-block px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              + Add Your First Gift
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {gifts.map((gift) => (
              <Link
                key={gift.id}
                href={`/gifts/${gift.id}`}
                className="block bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden"
              >
                {/* Image */}
                {gift.image_url && (
                  <div className="aspect-square overflow-hidden bg-gray-100">
                    <img
                      src={gift.image_url}
                      alt={gift.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                {/* Content */}
                <div className="p-5">
                  {/* Status Badge */}
                  <div className="mb-2">
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                        gift.status === 'idea'
                          ? 'bg-blue-100 text-blue-700'
                          : gift.status === 'purchased'
                          ? 'bg-green-100 text-green-700'
                          : gift.status === 'wrapped'
                          ? 'bg-purple-100 text-purple-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {gift.status}
                    </span>
                  </div>

                  {/* Name */}
                  <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
                    {gift.name}
                  </h3>

                  {/* Store/Brand */}
                  {(gift.store || gift.brand) && (
                    <p className="text-sm text-gray-500 mb-2">
                      {gift.brand && gift.store
                        ? `${gift.brand} · ${gift.store}`
                        : gift.brand || gift.store}
                    </p>
                  )}

                  {/* Price */}
                  {gift.price && (
                    <div className="text-xl font-bold text-purple-600 mb-3">
                      ${gift.price.toFixed(2)}
                    </div>
                  )}

                  {/* Recipients */}
                  {gift.recipients.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <div className="text-xs text-gray-500 mb-2">Gift for:</div>
                      <div className="flex flex-wrap gap-1">
                        {gift.recipients.map((recipient) => (
                          <span
                            key={recipient.id}
                            className="inline-block px-2 py-1 bg-purple-50 text-purple-700 rounded text-xs font-medium"
                          >
                            {recipient.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* No recipients indicator */}
                  {gift.recipients.length === 0 && (
                    <div className="mt-3 pt-3 border-t border-gray-100">
                      <div className="text-xs text-gray-400 italic">Not assigned yet</div>
                    </div>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}