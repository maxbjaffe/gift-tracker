import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Gift Tracker - Never Forget a Gift Again',
  description: 'AI-powered family gift management with price tracking and smart recommendations',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-2">
                <span className="text-3xl">🎁</span>
                <span className="text-xl font-bold text-gray-800">Gift Tracker</span>
              </div>
              
              <nav className="hidden md:flex items-center gap-6">
                <a href="/" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
                  Home
                </a>
                <a href="/recipients" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
                  Recipients
                </a>
                <a href="/gifts" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
                  Gifts
                </a>
                <a href="/dashboard" className="text-gray-600 hover:text-blue-600 font-medium transition-colors">
                  Dashboard
                </a>
              </nav>

              <button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors">
                Add Gift
              </button>
            </div>
          </div>
        </header>

        <main>
          {children}
        </main>

        <footer className="bg-gray-50 border-t border-gray-200 mt-16">
          <div className="container mx-auto px-4 py-8 text-center text-gray-600">
            <p>© 2025 Gift Tracker. Built with Next.js, Supabase, and Claude AI.</p>
          </div>
        </footer>
      </body>
    </html>
  )
}