'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/supabase';

type Recipient = {
  id: string;
  name: string;
  birthday: string | null;
};

type Gift = {
  id: string;
  name: string;
  price: number | null;
  status: string;
  created_at: string;
};

type StatusCount = {
  idea: number;
  researching: number;
  purchased: number;
  wrapped: number;
  given: number;
};

export default function DashboardPage() {
  const [recipients, setRecipients] = useState<Recipient[]>([]);
  const [gifts, setGifts] = useState<Gift[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  async function fetchData() {
    const supabase = createClient();
    
    const [recipientsRes, giftsRes] = await Promise.all([
      supabase.from('recipients').select('id, name, birthday'),
      supabase.from('gifts').select('id, name, price, status, created_at'),
    ]);

    if (recipientsRes.data) setRecipients(recipientsRes.data);
    if (giftsRes.data) setGifts(giftsRes.data);
    setLoading(false);
  }

  // Calculate stats
  const totalRecipients = recipients.length;
  const totalGifts = gifts.length;
  const totalValue = gifts.reduce((sum, gift) => sum + (gift.price || 0), 0);
  const purchasedCount = gifts.filter(g => g.status === 'purchased').length;

  // Status breakdown
  const statusCounts: StatusCount = gifts.reduce((acc, gift) => {
    const status = gift.status as keyof StatusCount;
    if (status in acc) {
      acc[status] = (acc[status] || 0) + 1;
    }
    return acc;
  }, { idea: 0, researching: 0, purchased: 0, wrapped: 0, given: 0 });

  // Upcoming birthdays
  const today = new Date();
  const upcomingBirthdays = recipients
    .filter(r => r.birthday)
    .map(r => {
      const bday = new Date(r.birthday + 'T00:00:00');
      const thisYear = new Date(today.getFullYear(), bday.getMonth(), bday.getDate());
      const nextYear = new Date(today.getFullYear() + 1, bday.getMonth(), bday.getDate());
      const nextBirthday = thisYear >= today ? thisYear : nextYear;
      const daysUntil = Math.ceil((nextBirthday.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      return { ...r, nextBirthday, daysUntil };
    })
    .sort((a, b) => a.daysUntil - b.daysUntil)
    .slice(0, 5);

  // Recent gifts
  const recentGifts = [...gifts]
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 5);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading dashboard...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">
            Gift Tracker Dashboard
          </h1>
          <p className="text-gray-600">
            Your personalized gift management overview
          </p>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Link href="/recipients">
            <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all cursor-pointer border-2 border-transparent hover:border-purple-300">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm mb-1">Total Recipients</p>
                  <p className="text-3xl font-bold text-purple-600">{totalRecipients}</p>
                </div>
                <div className="text-4xl">👥</div>
              </div>
            </div>
          </Link>

          <Link href="/gifts">
            <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all cursor-pointer border-2 border-transparent hover:border-purple-300">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm mb-1">Total Gift Ideas</p>
                  <p className="text-3xl font-bold text-pink-600">{totalGifts}</p>
                </div>
                <div className="text-4xl">🎁</div>
              </div>
            </div>
          </Link>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-1">Total Value</p>
                <p className="text-3xl font-bold text-green-600">
                  ${totalValue.toFixed(2)}
                </p>
              </div>
              <div className="text-4xl">💰</div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-600 text-sm mb-1">Purchased</p>
                <p className="text-3xl font-bold text-blue-600">{purchasedCount}</p>
              </div>
              <div className="text-4xl">✅</div>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Gift Status Breakdown */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Gift Status Breakdown
            </h2>
            <div className="space-y-4">
              {Object.entries(statusCounts).map(([status, count]) => {
                const percentage = totalGifts > 0 ? (count / totalGifts) * 100 : 0;
                const colors: Record<string, string> = {
                  idea: 'bg-purple-500',
                  researching: 'bg-blue-500',
                  purchased: 'bg-green-500',
                  wrapped: 'bg-yellow-500',
                  given: 'bg-pink-500',
                };
                return (
                  <div key={status}>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-gray-700 capitalize">
                        {status}
                      </span>
                      <span className="text-sm font-medium text-gray-700">
                        {count} ({percentage.toFixed(0)}%)
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className={`${colors[status]} h-2 rounded-full transition-all`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Upcoming Birthdays */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Upcoming Birthdays 🎂
            </h2>
            {upcomingBirthdays.length === 0 ? (
              <p className="text-gray-600">No upcoming birthdays</p>
            ) : (
              <div className="space-y-3">
                {upcomingBirthdays.map(recipient => (
                  <Link
                    key={recipient.id}
                    href={`/recipients/${recipient.id}`}
                    className="block p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-all"
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-semibold text-gray-900">{recipient.name}</p>
                        <p className="text-sm text-gray-600">
                          {recipient.nextBirthday.toLocaleDateString('en-US', {
                            month: 'long',
                            day: 'numeric',
                          })}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-purple-600">
                          {recipient.daysUntil}
                        </p>
                        <p className="text-xs text-gray-600">days</p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Recent Gift Ideas */}
        <div className="mt-8 bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Recent Gift Ideas
          </h2>
          {recentGifts.length === 0 ? (
            <p className="text-gray-600">No gifts added yet</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {recentGifts.map(gift => (
                <Link
                  key={gift.id}
                  href={`/gifts/${gift.id}`}
                  className="p-4 border-2 border-gray-200 rounded-lg hover:border-purple-400 hover:shadow-md transition-all"
                >
                  <h3 className="font-semibold text-gray-900 mb-2">{gift.name}</h3>
                  <div className="flex items-center justify-between">
                    <span
                      className={`px-2 py-1 text-xs rounded-full font-medium ${
                        gift.status === 'idea'
                          ? 'bg-purple-100 text-purple-700'
                          : gift.status === 'purchased'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}
                    >
                      {gift.status}
                    </span>
                    {gift.price && (
                      <span className="text-sm font-bold text-gray-900">
                        ${gift.price.toFixed(2)}
                      </span>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Quick Actions */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Link
            href="/recipients/new"
            className="block p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all text-center group hover:bg-gradient-to-br hover:from-purple-50 hover:to-pink-50"
          >
            <div className="text-4xl mb-2">👤</div>
            <div className="font-semibold text-gray-900 group-hover:text-purple-600">
              Add Recipient
            </div>
          </Link>

          <Link
            href="/gifts/new"
            className="block p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all text-center group hover:bg-gradient-to-br hover:from-purple-50 hover:to-pink-50"
          >
            <div className="text-4xl mb-2">🎁</div>
            <div className="font-semibold text-gray-900 group-hover:text-purple-600">
              Add Gift Idea
            </div>
          </Link>

          <Link
            href="/recipients"
            className="block p-6 bg-white rounded-xl shadow-lg hover:shadow-xl transition-all text-center group hover:bg-gradient-to-br hover:from-purple-50 hover:to-pink-50"
          >
            <div className="text-4xl mb-2">✨</div>
            <div className="font-semibold text-gray-900 group-hover:text-purple-600">
              Get AI Ideas
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}