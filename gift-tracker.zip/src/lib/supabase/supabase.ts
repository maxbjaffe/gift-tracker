// src/lib/supabase/supabase.ts

import { createClient as createSupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export function createClient() {
  return createSupabaseClient(supabaseUrl, supabaseAnonKey);
}

// TypeScript types for your database tables
export interface Recipient {
  id: string;
  name: string;
  relationship: string;
  birthday: string | null;
  age_range: string | null;
  interests: string | null;
  gift_preferences: string | null;
  favorite_stores: string | null;
  favorite_brands: string | null;
  restrictions: string | null;
  wishlist_items: string | null;
  max_budget: number | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface Gift {
  id: string;
  name: string;
  url: string | null;
  price: number | null;
  original_price: number | null;
  store: string | null;
  brand: string | null;
  category: string | null;
  description: string | null;
  image_url: string | null;
  status: string;
  purchase_date: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface GiftRecipient {
  id: string;
  gift_id: string;
  recipient_id: string;
  status: string | null;
  created_at: string;
}

export interface RecommendationFeedback {
  id: string;
  recipient_id: string;
  recommendation_name: string;
  recommendation_description: string | null;
  feedback_type: string;
  reason: string | null;
  created_at: string;
}